console.log('welcome to jsp')
function f1(){console.log ('hello')}
f1();